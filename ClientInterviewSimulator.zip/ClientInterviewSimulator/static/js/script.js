/**
 * Client Interview Simulator
 * Main JavaScript file that manages the interview simulator functionality
 */

// Global variables
let currentScenario = null;
let currentQuestionIndex = 0;
let userResponses = [];

// DOM elements
const scenarioSelector = document.getElementById('scenario-selector');
const interviewSection = document.getElementById('interview-section');
const resultsSection = document.getElementById('results-section');
const scenarioTitle = document.getElementById('scenario-title');
const questionText = document.getElementById('question-text');
const questionCounter = document.getElementById('question-counter');
const progressBar = document.getElementById('progress-bar');
const userAnswer = document.getElementById('user-answer');
const submitBtn = document.getElementById('submit-answer');
const feedbackSection = document.getElementById('feedback-section');
const feedbackText = document.getElementById('feedback-text');
const nextBtn = document.getElementById('next-question');
const restartBtn = document.getElementById('restart-btn');
const resultsSummary = document.getElementById('results-summary');

// Initialize event listeners when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    // Add event listeners for scenario selection buttons
    const scenarioButtons = document.querySelectorAll('.start-scenario-btn');
    scenarioButtons.forEach(button => {
        button.addEventListener('click', function() {
            const scenarioType = this.getAttribute('data-scenario');
            startScenario(scenarioType);
        });
    });

    // Submit answer button event listener
    if (submitBtn) {
        submitBtn.addEventListener('click', submitAnswer);
    }

    // Next question button event listener
    if (nextBtn) {
        nextBtn.addEventListener('click', nextQuestion);
    }

    // Restart button event listener
    if (restartBtn) {
        restartBtn.addEventListener('click', restart);
    }

    // Add animation to scenario cards
    const scenarioCards = document.querySelectorAll('.scenario-card');
    scenarioCards.forEach(card => {
        card.addEventListener('mouseenter', function() {
            this.classList.add('shadow');
        });
        card.addEventListener('mouseleave', function() {
            this.classList.remove('shadow');
        });
    });

    // Enable pressing Enter to submit in the textarea
    if (userAnswer) {
        userAnswer.addEventListener('keydown', function(event) {
            if (event.key === 'Enter' && event.ctrlKey) {
                submitAnswer();
            }
        });
    }
});

/**
 * Starts a new interview scenario
 * @param {string} type - The type of scenario to start
 */
function startScenario(type) {
    // Get the scenario data
    currentScenario = scenariosData[type];
    currentQuestionIndex = 0;
    userResponses = [];
    
    // Update the UI
    scenarioSelector.classList.add('d-none');
    interviewSection.classList.remove('d-none');
    resultsSection.classList.add('d-none');
    feedbackSection.classList.add('d-none');
    
    // Set the scenario title
    scenarioTitle.textContent = currentScenario.title;
    
    // Load the first question
    loadQuestion();
    
    // Scroll to the interview section
    interviewSection.scrollIntoView({ behavior: 'smooth' });
}

/**
 * Loads the current question into the UI
 */
function loadQuestion() {
    const question = currentScenario.questions[currentQuestionIndex];
    const total = currentScenario.questions.length;
    
    // Check if we're at the last question
    const isLastQuestion = currentQuestionIndex === total - 1;
    
    // Update question text with animation
    questionText.classList.remove('question-transition');
    // Trigger reflow to restart animation
    void questionText.offsetWidth;
    questionText.classList.add('question-transition');
    questionText.textContent = question.text;
    
    // Update question counter
    questionCounter.textContent = `Question ${currentQuestionIndex + 1} of ${total}`;
    
    // Update progress bar with smooth transition
    const progressPercentage = ((currentQuestionIndex + 1) / total) * 100;
    progressBar.style.width = `${progressPercentage}%`;
    progressBar.setAttribute('aria-valuenow', progressPercentage);
    progressBar.textContent = `${Math.round(progressPercentage)}%`;
    
    // Clear the answer field and enable/focus it
    userAnswer.value = '';
    userAnswer.disabled = false;
    userAnswer.focus();
    
    // If this is the last question, update the submit button text
    if (isLastQuestion) {
        submitBtn.textContent = 'Complete Interview';
    } else {
        submitBtn.textContent = 'Submit Answer';
    }
    
    // Hide feedback section
    feedbackSection.classList.add('d-none');
}

/**
 * Handles the answer submission
 */
function submitAnswer() {
    const answer = userAnswer.value.trim();
    
    // Don't proceed if answer is empty
    if (answer === '') {
        alert('Please provide an answer before proceeding.');
        return;
    }
    
    // Store the user's response
    userResponses.push({
        questionIndex: currentQuestionIndex,
        questionText: currentScenario.questions[currentQuestionIndex].text,
        answer: answer
    });
    
    // Provide feedback based on answer length
    provideFeedback(answer);
    
    // Show feedback section
    feedbackSection.classList.remove('d-none');
    
    // Scroll to feedback
    feedbackSection.scrollIntoView({ behavior: 'smooth' });
}

/**
 * Provides feedback based on the user's answer
 * @param {string} answer - The user's answer
 */
function provideFeedback(answer) {
    const question = currentScenario.questions[currentQuestionIndex];
    let feedback = '';
    
    // Determine feedback based on answer length
    if (answer.length < 50) {
        feedback = question.evaluation.short;
    } else if (answer.length < 150) {
        feedback = question.evaluation.medium;
    } else {
        feedback = question.evaluation.detailed;
    }
    
    // Display feedback
    feedbackText.innerHTML = feedback;
    
    // Add tips section to the feedback
    if (question.tips && question.tips.length > 0) {
        let tipsHtml = '<div class="mt-3"><strong>Tips for improvement:</strong><ul>';
        question.tips.forEach(tip => {
            tipsHtml += `<li>${tip}</li>`;
        });
        tipsHtml += '</ul></div>';
        feedbackText.innerHTML += tipsHtml;
    }
}

/**
 * Moves to the next question or completes the interview
 */
function nextQuestion() {
    currentQuestionIndex++;
    
    // Check if there are more questions
    if (currentQuestionIndex < currentScenario.questions.length) {
        loadQuestion();
    } else {
        completeInterview();
    }
}

/**
 * Completes the interview and shows results
 */
function completeInterview() {
    // Hide interview section and show results
    interviewSection.classList.add('d-none');
    resultsSection.classList.remove('d-none');
    
    // Generate results summary
    generateResultsSummary();
    
    // Scroll to results
    resultsSection.scrollIntoView({ behavior: 'smooth' });
}

/**
 * Generates a summary of the user's performance
 */
function generateResultsSummary() {
    let summaryHtml = `
        <h5>Interview Summary</h5>
        <p>Scenario: ${currentScenario.title}</p>
        <p>Questions answered: ${userResponses.length}</p>
        <div class="mt-4">
            <h6>Response Quality:</h6>
            <ul>
    `;
    
    // Count responses by quality
    let detailed = 0;
    let medium = 0;
    let short = 0;
    
    userResponses.forEach(response => {
        if (response.answer.length < 50) {
            short++;
        } else if (response.answer.length < 150) {
            medium++;
        } else {
            detailed++;
        }
    });
    
    // Add response quality to summary
    summaryHtml += `
        <li><strong>Comprehensive responses:</strong> ${detailed}</li>
        <li><strong>Good responses:</strong> ${medium}</li>
        <li><strong>Brief responses:</strong> ${short}</li>
    `;
    
    // Add overall assessment
    let overallFeedback = '';
    if (detailed > medium && detailed > short) {
        overallFeedback = 'Your answers were generally comprehensive and detailed. You demonstrated strong communication skills!';
    } else if (medium > short) {
        overallFeedback = 'Your answers were good but could use more detail and examples to make them more impactful.';
    } else {
        overallFeedback = 'Your answers tended to be brief. Try to elaborate more and provide specific examples to strengthen your responses.';
    }
    
    summaryHtml += `
            </ul>
            <div class="alert alert-info mt-3">
                <strong>Overall Assessment:</strong> ${overallFeedback}
            </div>
            <div class="mt-3">
                <strong>Next Steps:</strong>
                <p>Practice makes perfect! Try another scenario or repeat this one to improve your responses.</p>
            </div>
        </div>
    `;
    
    // Update the results summary
    resultsSummary.innerHTML = summaryHtml;
}

/**
 * Restarts the simulator and returns to scenario selection
 */
function restart() {
    // Reset global variables
    currentScenario = null;
    currentQuestionIndex = 0;
    userResponses = [];
    
    // Show scenario selector, hide other sections
    scenarioSelector.classList.remove('d-none');
    interviewSection.classList.add('d-none');
    resultsSection.classList.add('d-none');
    
    // Scroll to scenario selector
    scenarioSelector.scrollIntoView({ behavior: 'smooth' });
}
