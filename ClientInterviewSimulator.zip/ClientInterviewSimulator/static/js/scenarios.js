/**
 * Interview Scenarios Data
 * This file contains all the scenario data for the Client Interview Simulator
 */

const scenariosData = {
    // Client Meeting Scenario
    client_meeting: {
        title: "Client Meeting",
        description: "Initial meeting with a potential client to discuss a new project",
        questions: [
            {
                id: 1,
                text: "Could you tell me about your experience with similar projects?",
                tips: [
                    "Mention specific, relevant past projects",
                    "Quantify your achievements where possible",
                    "Highlight challenges you overcame"
                ],
                evaluation: {
                    short: "Your answer is quite brief. Consider elaborating on your experience with specific examples of similar projects you've worked on, the challenges you faced, and the results you achieved.",
                    medium: "Good start! To make your answer stronger, try to include more specifics about your successful projects, quantify your results, and explain how your experience applies to the client's needs.",
                    detailed: "Excellent answer! You've provided specific examples of your experience, demonstrated your expertise, and shown how your skills apply to this client's project."
                }
            },
            {
                id: 2,
                text: "What makes you or your company stand out from other service providers?",
                tips: [
                    "Focus on your unique value proposition",
                    "Provide concrete examples, not just claims",
                    "Align your strengths with client needs"
                ],
                evaluation: {
                    short: "Your answer needs more substance. To stand out, highlight your unique approach, specialization, or methodology that differentiates you from competitors.",
                    medium: "Good points, but you could strengthen your answer by providing specific examples that demonstrate your unique value proposition and how it has benefited past clients.",
                    detailed: "Outstanding response! You've clearly articulated your unique strengths, provided supporting examples, and shown why you're the ideal choice for this client."
                }
            },
            {
                id: 3,
                text: "How do you approach deadlines and ensure timely delivery?",
                tips: [
                    "Explain your project management methodology",
                    "Discuss communication and progress tracking",
                    "Mention contingency planning"
                ],
                evaluation: {
                    short: "Consider expanding your answer to include your specific process for managing timelines, tracking progress, and handling potential delays.",
                    medium: "Good response. To improve, add more details about your project management approach, communication practices, and how you've successfully managed tight deadlines in the past.",
                    detailed: "Excellent answer! You've outlined a comprehensive approach to managing deadlines, including your methodology, communication plan, and strategies for handling unexpected challenges."
                }
            },
            {
                id: 4,
                text: "How would you handle scope changes during the project?",
                tips: [
                    "Emphasize flexibility and adaptability",
                    "Explain your change management process",
                    "Discuss transparent communication"
                ],
                evaluation: {
                    short: "Try to provide more specifics about your change management process and how you balance flexibility with project constraints.",
                    medium: "Good answer. To make it stronger, include examples of how you've successfully managed scope changes in past projects and your specific approach to evaluation and implementation.",
                    detailed: "Great response! You've demonstrated a balanced approach to managing scope changes that shows flexibility while maintaining project integrity, and you've supported it with concrete examples."
                }
            },
            {
                id: 5,
                text: "What questions do you have about our project?",
                tips: [
                    "Ask thoughtful, well-researched questions",
                    "Focus on understanding client needs and goals",
                    "Demonstrate strategic thinking"
                ],
                evaluation: {
                    short: "Asking questions is important, but try to make them more specific and strategic to show your interest in understanding the client's business and project goals.",
                    medium: "Good questions. To make an even better impression, ask more probing questions that demonstrate your expertise and show you're thinking about how to deliver the best results.",
                    detailed: "Excellent questions! You've demonstrated genuine interest in the client's business, shown strategic thinking, and positioned yourself as a consultant rather than just a service provider."
                }
            }
        ]
    },
    
    // Budget Negotiation Scenario
    budget_negotiation: {
        title: "Budget Negotiation",
        description: "Discussing project scope and pricing with a potential client",
        questions: [
            {
                id: 1,
                text: "What is your rate for a project like this?",
                tips: [
                    "Explain your pricing structure confidently",
                    "Emphasize value rather than just cost",
                    "Consider offering options at different price points"
                ],
                evaluation: {
                    short: "Your answer is brief and focuses mainly on numbers. Consider explaining the value behind your rates and what the client receives for their investment.",
                    medium: "Good response. To strengthen it, add more details about what's included in your pricing and how it represents value for the client compared to alternatives.",
                    detailed: "Excellent answer! You've confidently explained your rates while emphasizing the value and ROI the client will receive, positioning your services as an investment rather than an expense."
                }
            },
            {
                id: 2,
                text: "Our budget is lower than your quote. Can you reduce your price?",
                tips: [
                    "Avoid immediately discounting your services",
                    "Discuss adjusting scope to meet budget",
                    "Emphasize the relationship between price and value"
                ],
                evaluation: {
                    short: "Be careful about immediately reducing your price. Instead, explore options to adjust the project scope or deliverables to meet their budget while maintaining your rates.",
                    medium: "Good negotiation approach. You could improve by more clearly explaining the relationship between price and value, and by offering concrete alternatives that meet their budget constraints.",
                    detailed: "Excellent negotiation! You've maintained your value while showing flexibility, offering alternative approaches that respect both their budget constraints and your professional rates."
                }
            },
            {
                id: 3,
                text: "How do you handle additional costs that might arise during the project?",
                tips: [
                    "Explain your approach to estimating and contingencies",
                    "Discuss your communication process for potential overages",
                    "Emphasize transparency and no surprises"
                ],
                evaluation: {
                    short: "Your answer needs more detail about your specific process for handling unexpected costs and how you communicate with clients about budget changes.",
                    medium: "Good response. To improve, add specific examples of how you've handled unexpected costs in the past, focusing on your communication process and problem-solving approach.",
                    detailed: "Excellent answer! You've outlined a clear, transparent process for handling additional costs that emphasizes proactive communication and collaborative problem-solving."
                }
            },
            {
                id: 4,
                text: "What payment terms do you typically work with?",
                tips: [
                    "Clearly explain your standard payment structure",
                    "Discuss milestones and deliverables",
                    "Be confident but indicate some flexibility"
                ],
                evaluation: {
                    short: "Your answer is too brief. Include more details about your payment schedule, milestone-based payments, and how you align payment with project deliverables.",
                    medium: "Good explanation of your payment terms. To improve, be more specific about how your payment structure benefits both you and the client, and how it aligns with project milestones.",
                    detailed: "Excellent response! You've clearly outlined your payment terms while explaining how they benefit the client, reduce risk, and ensure mutual commitment to project success."
                }
            },
            {
                id: 5,
                text: "How do you handle tight deadlines or rush projects in terms of pricing?",
                tips: [
                    "Explain your rush fee policy if you have one",
                    "Discuss resource allocation for urgent projects",
                    "Be honest about what is and isn't possible"
                ],
                evaluation: {
                    short: "Your answer needs more detail about your specific policies for rush work, including how you determine pricing adjustments and what clients can expect.",
                    medium: "Good explanation, but try to be more specific about how you balance quality, timeline, and cost when handling rush projects, using concrete examples from past work.",
                    detailed: "Excellent answer! You've clearly explained your approach to rush projects, including pricing considerations, while emphasizing your commitment to maintaining quality standards."
                }
            }
        ]
    }
};
